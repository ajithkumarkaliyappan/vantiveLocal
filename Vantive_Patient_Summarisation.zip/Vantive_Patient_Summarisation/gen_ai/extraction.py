import sys
sys.path.append('.')
sys.path.append('..')

import os
import json
from gen_ai.llm_connector import LLMConnector
from utils import gpt5_processed_patient_data_folder

def extract_attributes(patient_id, sessions):
    print("Extracting attributes from JSON...")
    # GPT5 Prompt
    prompt = f"""
    You are an expert medical data parser. You will be given multiple dialysis session JSONs for a patient for different dates. 

    Task:
    - Identify and extract only the medically important or operationally useful attributes.
    - Ignore irrelevant metadata like byte counts or revision numbers.
    - If data is missing, flag it in an "alerts" field.

    Output: valid JSON list of daily records.

    Patient: {patient_id}
    Sessions: {sessions}
    """
    llm = LLMConnector()
    extracted = llm.get_response(
        prompt,
        system_prompt="You are a medical data parser that outputs only valid JSON."
    )
    output_dir = gpt5_processed_patient_data_folder
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    
    extracted_json_file = os.path.join(output_dir, f"Processed_{patient_id}.json")
    with open(extracted_json_file, "w", encoding="utf-8") as f:
        f.write(extracted)

    return json.loads(extracted)