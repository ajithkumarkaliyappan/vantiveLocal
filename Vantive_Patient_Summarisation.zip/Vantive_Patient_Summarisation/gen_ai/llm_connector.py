import sys
sys.path.append('.')
sys.path.append('..')

import os
from openai import AzureOpenAI
from dotenv import load_dotenv
load_dotenv()

subscription_key = os.getenv('AZURE_OPENAI_API_KEY')
azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')

class LLMConnector:
    def __init__(self, 
                 api_version:str="2024-12-01-preview", 
                 endpoint: str=azure_endpoint, 
                 subscription_key: str=subscription_key, 
                 deployment_model:str="gpt-5"):
                
        self.client = AzureOpenAI(
            api_version=api_version,
            azure_endpoint=endpoint,
            api_key=subscription_key
        )
        self.deployment_model = deployment_model
        print("LLMConnector Created")

    def get_response(self, content, system_prompt=None):
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": content})

        response = self.client.chat.completions.create(
            messages=messages,
            max_completion_tokens=4096,
            temperature=1.0,
            top_p=1.0,
            model=self.deployment_model
        )
        return response.choices[0].message.content
    
if __name__=="__main__":
    llm = LLMConnector()
    response = llm.get_response(content="Who are you?")
    print(response)