import sys
sys.path.append('.')
sys.path.append('..')

import os
import pandas as pd
from io import StringIO
from gen_ai.llm_connector import LLMConnector
from utils import prediction_csv_file

def get_prediction_prompt(patient_details):
    prediction_prompt = f"""
        You are a dialysis medical assistant and a strong data analyst. 
        Given below are the dialysis details of a patient for different dates in JSON format:
        
        {patient_details}

        Using the available data, predict the future values for the following:
        'patient weight', 'systolic BP', 'diastolic BP', 'average dwell time in seconds', 'dwell cycles', 'prescribed uf total target' and 'uf total' only for the next time interval.

        Provide your response *in strict CSV format* with the following columns:
        - patient_id
        - date
        - weight
        - bp_systolic
        - bp_diastolic
        - average_dwell_time_seconds
        - dwell_cycles
        - prescribed_uf
        - actual_uf
        - is_predicted

        Include both the existing values and the predicted values in the same table. 
        For predicted rows, set 'is_predicted' to True; for existing rows, set it to False.
        """
    return prediction_prompt
            
def predict_next_uf_and_dwell(patient_id, extracted_data):
    # Summarise using LLM
    llm = LLMConnector()
    print(f"Predicting values for {patient_id}")
    prediction_prompt = get_prediction_prompt(patient_details=extracted_data)
    prediction_output = llm.get_response(
        prediction_prompt,
        system_prompt="You are a medical assistant specialised in predicting health trends of dialysis patient."
    )    
    print("Prediction done!")
    
    new_df = pd.read_csv(StringIO(prediction_output))
    
    # Append to existing predictions CSV file
    if os.path.exists(prediction_csv_file):
        existing_pred = pd.read_csv(prediction_csv_file)
        df_final = pd.concat([existing_pred, new_df], ignore_index=True)
    else:
        df_final = new_df

    df_final.to_csv(prediction_csv_file, index=False)
    print(f"{prediction_csv_file} created!")
    return prediction_output