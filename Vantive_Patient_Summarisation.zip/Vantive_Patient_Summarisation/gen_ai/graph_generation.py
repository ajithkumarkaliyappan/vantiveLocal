import sys
sys.path.append('.')
sys.path.append('..')

import os
import json
import matplotlib.pyplot as plt
import pandas as pd
import regex as re
import pandas as pd
from pathlib import Path

def json_to_df(json_data):
    # Flatten JSON automatically
    df = pd.json_normalize(json_data)
    # print(f"Original DF columns:\n{df.columns}")

    # Define regex patterns and their desired constant names
    pattern_map = {
        r'.*patient[_]?id.*': "patient_id",
        r'.*date.*': "date",
        r'.*weight.*': "weight",
        r'.*systolic.*': "systolic_bp",
        r'.*diastolic.*': "diastolic_bp",
        r'.*average[_]?dwell[_]?time.*': "average_dwell_time",
        r'.*total[_]?fill.*': "total_fill_volume",
        r'.*total[_]?drain.*': "total_drain_volume",
        r'.*prescription.total[_]?uf[_]?target.*': "prescribed_uf_target",
        r'.*summary.*uf[_]?total.*': "actual_uf_total",
    }

    # Manual filtering using re.IGNORECASE
    selected_cols = []
    rename_map = {}

    for col in df.columns:
        for pattern, const_name in pattern_map.items():
            if re.search(pattern, col, re.IGNORECASE):
                selected_cols.append(col)
                rename_map[col] = const_name
                break

    # Create selective dataframe
    selective_df = df[selected_cols].rename(columns=rename_map)
    selective_df = selective_df.loc[:, ~selective_df.columns.duplicated()]
    print("Duplicates=", selective_df.columns[selective_df.columns.duplicated()])
    print("Full DataFrame:\n", df.shape, "\n")
    return selective_df

def plot_patient_trends(json_data, patient_id):
    df = json_to_df(json_data=json_data)
    df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.strftime("%d-%m-%Y")
    # Filter for the patient
    patient_df = df[df["patient_id"] == patient_id].copy()
    print(f"Dimensions: {patient_df.shape}")

    if patient_df.empty:
        print(f"No data found for {patient_id}")
        return

    # Sort by date to avoid zig-zag lines
    patient_df = patient_df.sort_values("date")
    
    # Plot all trends
    print("Plotting graphs...")
    plot_weight_lineplot(patient_id, patient_df)
    plot_bp_bar_graph(patient_id, patient_df)
    plot_completion_percentage_bar(patient_id, patient_df)

def plot_weight_lineplot(patient_id, patient_df):
    patient_df = patient_df.dropna(subset=['weight'])
    patient_df = patient_df.reset_index(drop=True)

    # Line plot of Weight
    plt.plot(patient_df["date"], patient_df['weight'], marker="o", color="#800080")   
    
    plt.xlabel("Date")
    plt.ylabel("Weight (kg)")
    plt.title(f"Body Weight Trend over time for {patient_id}")
    plt.tight_layout()
    graph_folder = f"graphs/{patient_id}/"
    if not os.path.exists(graph_folder):
         os.makedirs(graph_folder, exist_ok=True)
    plt.savefig(os.path.join(graph_folder, f'{patient_id}_Weight.png'))
    plt.show()

def plot_bp_bar_graph(patient_id, patient_df):
    # BP BAR GRAPH
    x = range(len(patient_df))
    bar_width = 0.4
    overlap_offset = bar_width * 0.3

    patient_df = patient_df.dropna(subset=["systolic_bp", "diastolic_bp"])
    patient_df = patient_df.reset_index(drop=True)

    plt.bar([i - overlap_offset for i in x], patient_df["systolic_bp"], width=bar_width, label="Systolic", color="#800080")
    plt.bar([i + overlap_offset for i in x], patient_df["diastolic_bp"], width=bar_width, label="Diastolic", color="#40826d")

    # Add value labels above bars
    for i, val in enumerate(patient_df["systolic_bp"]):
        plt.text(i - overlap_offset, val + 1, str(val), ha="center", va="bottom", fontsize=9)
    for i, val in enumerate(patient_df["diastolic_bp"]):
        plt.text(i + overlap_offset, val + 1, str(val), ha="center", va="bottom", fontsize=9)
    plt.xlabel("Date")
    plt.ylabel("Blood Pressure (mmHg)")
    plt.title(f"Blood Pressure Trend over time for {patient_id}")
    plt.legend()
    plt.xticks(x, patient_df["date"])
    plt.tight_layout()

    graph_folder = f"graphs/{patient_id}/"
    if not os.path.exists(graph_folder):
         os.makedirs(graph_folder, exist_ok=True)
    plt.savefig(os.path.join(graph_folder, f"{patient_id}_BP.png"))
    plt.show()

def plot_completion_percentage_bar(patient_id, patient_df):
    # UF completion percentage Bar Graph
    x = range(len(patient_df))
    bar_width = 0.4
    
    patient_df = patient_df.dropna(subset=["prescribed_uf_target", "actual_uf_total"])
    patient_df = patient_df.reset_index(drop=True)

    patient_df["completion_pct"] = (patient_df["actual_uf_total"] /
                                    patient_df["prescribed_uf_target"]) * 100

    # Plot bars
    plt.bar(x, patient_df["completion_pct"], width=bar_width, color="#40826d", label="UF Completion %")

    # Add value labels above bars
    for i, val in enumerate(patient_df["completion_pct"]):
        plt.text(i, val + 2, f"{val:.1f}%", ha="center", va="bottom", fontsize=9)

    plt.xlabel("Date")
    plt.ylabel("UF Completion (%)")
    plt.title(f"UF Completion Trend over time for {patient_id}")
    plt.legend()
    plt.xticks(x, patient_df["date"])
    plt.tight_layout()

    graph_folder = f"graphs/{patient_id}/"
    if not os.path.exists(graph_folder):
         os.makedirs(graph_folder, exist_ok=True)
    plt.savefig(os.path.join(graph_folder, f"{patient_id}_Completion.png"))
    plt.show()

def combine_all_patient_data_for_graph():
    extracted_data_folder = Path('data/Processed_Patient_Data')
    df_list = []
    for json_file in extracted_data_folder.iterdir():
        if json_file.suffix == '.json':
            with open(json_file, "r", encoding="utf-8") as f:
                extracted_data = json.load(f)
            df = json_to_df(extracted_data)
            print("Individual DF:", df.shape)
            df_list.append(df)
    combined_df = pd.concat(df_list, axis=0, ignore_index=True)
    combined_df.reset_index(drop=True, inplace=True)
    print("Combined DF =", combined_df.shape)
    print(combined_df.head())
    print(combined_df.columns)
    combined_df.to_csv('data/All_patients_selective_DF.csv', index=False)

def plot_cohort_average_weight_scatter_plot(all_patients_csv='data/All_patients_selective_DF.csv'):
    df = pd.read_csv(all_patients_csv)
    print("Loaded df:", df.shape)
    
    avg_weight_by_patient = df.groupby('patient_id')['weight'].mean().round(1)

    # Compute overall average weight
    overall_avg_weight = df['weight'].mean()

    # Create scatter plot
    # plt.figure(figsize=(6.4, 4.8))
    scatter = plt.scatter(avg_weight_by_patient.index,
                            avg_weight_by_patient.values,
                            s=avg_weight_by_patient.values * 5,  # Size proportional to weight
                            c=avg_weight_by_patient.values,      # Color proportional to weight
                            cmap='Purples',
                            edgecolors='purple')
    plt.axhline(y=overall_avg_weight, color="#40826d", linestyle='--', label=f'Cohort Average Weight ({overall_avg_weight:.2f})')

    for i, val in enumerate(avg_weight_by_patient):
        plt.text(i, val + 1.5, f"{val}", ha="center", va="bottom", fontsize=10, weight="roman")

    # Define standardized limits based on range
    weight_range = avg_weight_by_patient.values.max() - avg_weight_by_patient.values.min()
    bottom_limit = avg_weight_by_patient.values.min() - 0.1 * weight_range
    top_limit = avg_weight_by_patient.values.max() + 0.1 * weight_range

    plt.ylim(bottom=bottom_limit, top=top_limit)
    
    # Add labels and title
    plt.xlabel('Patient ID')
    plt.ylabel('Average Weight (kg)')
    plt.title('Average Weight per Patient')
    plt.colorbar(scatter, label='Weight')
    plt.legend()
    plt.tight_layout()
    # plt.grid(True)

    # Save the plot
    plt.savefig('graphs/average_1_weight_scatter_plot.png')
    plt.show()

def plot_cohort_average_bp_bar_graph(all_patients_csv='data/All_patients_selective_DF.csv'):
    df = pd.read_csv(all_patients_csv)
    print("Loaded df:", df.shape)
    patient_df = df.groupby('patient_id')[['systolic_bp', 'diastolic_bp']].mean().round(1)

    # BP BAR GRAPH
    x = range(len(patient_df))
    bar_width = 0.4
    overlap_offset = bar_width * 0.3

    plt.bar([i - overlap_offset for i in x], patient_df["systolic_bp"], width=bar_width, label="Systolic", color="#800080")
    plt.bar([i + overlap_offset for i in x], patient_df["diastolic_bp"], width=bar_width, label="Diastolic", color="#40826d")

    # Add value labels above bars
    for i, val in enumerate(patient_df["systolic_bp"]):
        plt.text(i - overlap_offset, val + 1.5, str(val), ha="center", va="bottom", fontsize=10, weight="roman")
    for i, val in enumerate(patient_df["diastolic_bp"]):
        plt.text(i + overlap_offset, val + 1.5, str(val), ha="center", va="bottom", fontsize=10, weight="roman")
    
    # Add mean line
    overall_avg_sys = patient_df['systolic_bp'].mean().round(1)
    overall_avg_dias = patient_df['diastolic_bp'].mean().round(1)
    plt.axhline(y=overall_avg_sys, color="#800080", linestyle='--', label=f'Cohort Average Systolic BP ({overall_avg_sys})')
    plt.axhline(y=overall_avg_dias, color="#40826d", linestyle='-.', label=f'Cohort Average Diastolic BP ({overall_avg_dias})')

    # Define standardized limits based on range
    weight_range = patient_df['systolic_bp'].max() #- patient_df.values.min()
    # bottom_limit = patient_df.values.min() - 0.1 * weight_range
    top_limit = patient_df.values.max() + 0.1 * weight_range

    plt.ylim(bottom=0, top=top_limit)

    plt.xlabel("Patient ID")
    plt.ylabel("Blood Pressure (mmHg)")
    plt.title(f"Average Blood Pressure per Patient")
    plt.legend()
    plt.xticks(x, patient_df.index)
    plt.tight_layout()

    graph_folder = "graphs"
    # if not os.path.exists(graph_folder):
    #      os.makedirs(graph_folder, exist_ok=True)
    plt.savefig(os.path.join(graph_folder, "average_2_bp_bar_graph.png"))
    plt.show()
    

def plot_cohort_average_uf_completion_bar(all_patients_csv='data/All_patients_selective_DF.csv'):
    # Load data
    df = pd.read_csv(all_patients_csv)
    print("Loaded df:", df.shape)

    # Drop missing UF data
    df = df.dropna(subset=["prescribed_uf_target", "actual_uf_total"]).reset_index(drop=True)

    # Compute completion percentage
    df["completion_pct"] = ((df["actual_uf_total"] / df["prescribed_uf_target"]) * 100).round(1)

    # Average per patient
    patient_df = df.groupby("patient_id")["completion_pct"].mean().round(1)

    # Prepare x-axis
    x = range(len(patient_df))
    bar_width = 0.5
    main_color = "#40826d"  # Teal

    # plt.figure(figsize=(10, 6))

    # --- Plot bars ---
    plt.bar(
        x,
        patient_df,
        width=bar_width,
        color=main_color,
        edgecolor="black",
        linewidth=1.5,
        label="Average UF Completion %"
    )

    # --- Add value labels ---
    for i, val in enumerate(patient_df):
        plt.text(i, val + 1, f"{val}%", ha="center", va="bottom", fontsize=10, weight="roman")

    # --- Cohort average line ---
    overall_avg = patient_df.mean().round(1)
    plt.axhline(
        y=overall_avg,
        color="#800080",
        linestyle="--",
        label=f"Cohort Average UF Completion ({overall_avg}%)"
    )

    # Define standardized limits based on range
    weight_range = patient_df.values.max() #- patient_df.values.min()
    top_limit = patient_df.values.max() + 0.1 * weight_range

    plt.ylim(bottom=0, top=top_limit)
    
    # --- Styling ---
    plt.xlabel("Patient ID")
    plt.ylabel("UF Completion (%)")
    plt.title("Average UF Completion % per Patient")
    plt.xticks(x, patient_df.index) #, ha="right")
    plt.legend(loc="best")
    plt.tight_layout()

    # --- Save graph ---
    graph_folder = "graphs"
    # os.makedirs(graph_folder, exist_ok=True)
    plt.savefig(os.path.join(graph_folder, "average_4_uf_completion_bar_graph.png"))
    plt.show()

def plot_cohort_average_dwell_scatter_plot(all_patients_csv='data/All_patients_selective_DF.csv'):
    df = pd.read_csv(all_patients_csv)
    print("Loaded df:", df.shape)
    
    avg_dwell_cycles_by_patient = df.groupby('patient_id')['dwell_cycles'].mean().round(1)

    # Compute overall average weight
    overall_avg_dwell = df['dwell_cycles'].mean().round(1)

    # Create scatter plot
    # plt.figure(figsize=(8, 6))
    plt.scatter(avg_dwell_cycles_by_patient.index,
                            avg_dwell_cycles_by_patient.values,
                            color="#800080", marker="D", edgecolors="black", s=150)
                            # s=avg_dwell_cycles_by_patient.values * 5) # Size proportional to weight
                            # c=avg_dwell_cycles_by_patient.values,      # Color proportional to weight
                            # cmap='Purples',
                            # edgecolors='purple')
    plt.axhline(y=overall_avg_dwell, color="#40826d", linestyle='--', label=f'Cohort Average Dwell Cycles = {int(overall_avg_dwell)}')

    for i, val in enumerate(avg_dwell_cycles_by_patient):
        plt.text(i, val+0.15, f"{val}", ha="center", va="bottom", fontsize=10, weight="roman")

    # Add labels and title
    plt.ylim(bottom=0, top=max(avg_dwell_cycles_by_patient.values)*1.2)
    plt.xlabel('Patient ID')
    plt.ylabel('Average Dwell Cycles')
    plt.title('Average Dwell Cycles per Patient')
    plt.legend()
    plt.tight_layout()
    # plt.grid(True)

    # Save the plot
    plt.savefig('graphs/average_3_dwell_cycles_scatter_plot.png')
    plt.show()


if __name__ == "__main__":
    # plot_cohort_average_dwell_scatter_plot()
    plot_cohort_average_weight_scatter_plot()
    # plot_cohort_average_uf_completion_bar()
    # plot_cohort_average_bp_bar_graph()