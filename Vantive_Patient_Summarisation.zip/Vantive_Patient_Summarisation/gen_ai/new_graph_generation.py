import sys
sys.path.append('.')
sys.path.append('..')

import os
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import matplotlib.lines as mlines
from utils import prediction_csv_file, graph_folder

def plot_patient_trends_with_predictions(patient_id, csv_file=prediction_csv_file):
    patient_id = patient_id.replace(" ", "_")
    df = pd.read_csv(csv_file)
    df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.strftime("%d-%m-%Y")
    
    # Filter for the patient
    patient_df = df[df["patient_id"] == patient_id].copy()
    print(f"Dimensions: {patient_df.shape}")

    if patient_df.empty:
        print(f"No data found for {patient_id}")
        return

    # Sort by date to avoid zig-zag lines
    patient_df = patient_df.sort_values("date")
    
    # Plot all trends
    print("Plotting graphs...")
    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    if not os.path.exists(graphs_folder):
        os.makedirs(graphs_folder, exist_ok=True)
    
    plot_weight_lineplot(patient_id, patient_df)
    plot_bp_bar_graph(patient_id, patient_df)
    plot_completion_percentage_bar(patient_id, patient_df)
    plot_dwell_cycles_scatter_plot(patient_id, patient_df)

# Weight Line Plot
def plot_weight_lineplot(patient_id, patient_df):
    print("Weight")
    patient_df = patient_df.dropna(subset=['weight'])
    patient_df = patient_df.reset_index(drop=True)
    patient_df['weight'] = patient_df['weight'].astype(int)
    # Separate actual and predicted data
    actual_df = patient_df[patient_df['is_predicted'] == False]
    predicted_df = patient_df[patient_df['is_predicted'] == True]

    # Combine last actual point with predicted data for continuous line
    if not actual_df.empty and not predicted_df.empty:
        last_actual = actual_df.iloc[-1]
        predicted_df = pd.concat([pd.DataFrame([last_actual]), predicted_df], ignore_index=True)

    # Plot actual weights with solid line
    plt.plot(actual_df['date'], actual_df['weight'], marker='o', color='#800080', label='Actual Weight')

    # Plot predicted weights with dotted line
    plt.plot(predicted_df['date'], predicted_df['weight'], marker='o', color='#800080', label='Predicted Weight', linestyle='dashed')

    # Calculate dynamic offset based on weight range
    weight_range = patient_df['weight'].max() - patient_df['weight'].min()
    offset = weight_range * 0.04

    # Annotate predicted data points
    for i, row in patient_df.iterrows():
        plt.text(row['date'], row['weight'] + offset, str(row['weight']), ha='center', fontsize=10, weight="roman")

    # bottom_limit = math.floor(min(patient_df['weight']) / 5) * 5
    
    # Define standardized limits based on range
    bottom_limit = patient_df['weight'].min() - 0.1 * weight_range
    top_limit = patient_df['weight'].max() + 0.1 * weight_range

    # bottom_limit = (min(patient_df['weight'])) - 1
    plt.ylim(bottom=bottom_limit, top=top_limit)
    plt.xlabel("Date")
    plt.ylabel("Weight (kg)")
    plt.title(f"Body Weight Trend - {patient_id}")
    plt.legend()
    plt.tight_layout()

    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    plt.savefig(os.path.join(graphs_folder, f'{patient_id}_1_Weight.png'))
    plt.show()

# BLOOD PRESSURE BAR GRAPH
def plot_bp_bar_graph(patient_id, patient_df):
    print("BP")
    # Drop missing values
    patient_df = patient_df.dropna(subset=["bp_systolic", "bp_diastolic"]).reset_index(drop=True)
    x = range(len(patient_df))
    bar_width = 0.4
    overlap_offset = bar_width * 0.3

    systolic_color = "#800080"   # Purple
    diastolic_color = "#40826d"  # Teal

    for i in x:
        is_pred = patient_df.loc[i, "is_predicted"]

        # --- Systolic Bar ---
        plt.bar(
            i - overlap_offset,
            patient_df.loc[i, "bp_systolic"],
            width=bar_width,
            label="Systolic" if i == 0 else "",
            facecolor="white" if is_pred else systolic_color,
            edgecolor=systolic_color,
            hatch="\\" if is_pred else None,
            linewidth=1.8
        )

        # --- Diastolic Bar ---
        plt.bar(
            i + overlap_offset,
            patient_df.loc[i, "bp_diastolic"],
            width=bar_width,
            label="Diastolic" if i == 0 else "",
            facecolor="white" if is_pred else diastolic_color,
            edgecolor=diastolic_color,
            hatch="//" if is_pred else None,
            linewidth=1
        )

        # Add value labels
        plt.text(i - overlap_offset, patient_df.loc[i, "bp_systolic"] + 1,
                 str(int(patient_df.loc[i, "bp_systolic"])), ha="center", va="bottom", fontsize=10, weight="roman")
        plt.text(i + overlap_offset, patient_df.loc[i, "bp_diastolic"] + 1,
                 str(int(patient_df.loc[i, "bp_diastolic"])), ha="center", va="bottom", fontsize=10, weight="roman")

    # --- Custom Legend ---
    legend_elements = [
        Patch(facecolor=systolic_color, edgecolor=systolic_color, label="Actual Systolic"),
        Patch(facecolor=diastolic_color, edgecolor=diastolic_color, label="Actual Diastolic"),
        Patch(facecolor="white", edgecolor=systolic_color, hatch="\\", linewidth=1.8, label="Predicted Systolic"),
        Patch(facecolor="white", edgecolor=diastolic_color, hatch="//", linewidth=1.8, label="Predicted Diastolic")
    ]

    plt.xlabel("Date")
    plt.ylabel("Blood Pressure (mmHg)")
    plt.title(f"Blood Pressure Trend - {patient_id}")
    plt.xticks(x, patient_df["date"])
    plt.legend(handles=legend_elements, loc="best")
    plt.tight_layout()
    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    plt.savefig(os.path.join(graphs_folder, f"{patient_id}_2_BP.png"))
    plt.show()

# UF COMPLETION % BAR GRAPH
def plot_completion_percentage_bar(patient_id, patient_df):
    print("UF COMPLETION")
    # Drop missing values
    patient_df = patient_df.dropna(subset=["prescribed_uf", "actual_uf"]).reset_index(drop=True)
    x = range(len(patient_df))
    bar_width = 0.4
    main_color = "#40826d"  # Teal

    # Compute completion percentage
    patient_df["completion_pct"] = ((patient_df["actual_uf"] / patient_df["prescribed_uf"])*100).round(1)

    # Plot bars with predicted styling
    for i, val in enumerate(patient_df["completion_pct"]):
        is_pred = patient_df.loc[i, "is_predicted"] if "is_predicted" in patient_df.columns else False

        plt.bar(
            i,
            val,
            width=bar_width,
            facecolor="white" if is_pred else main_color,
            edgecolor=main_color,
            hatch="//" if is_pred else None,
            linewidth=1.8,
            label="UF Completion %" if i == 0 else ""
        )

        # Add value label
        plt.text(i, val + 2, f"{val}%", ha="center", va="bottom", fontsize=9)

    # --- Custom Legend ---
    legend_elements = [
        Patch(facecolor=main_color, edgecolor=main_color, label="Actual"),
        Patch(facecolor="white", edgecolor=main_color, hatch="//", linewidth=1.8, label="Predicted")
    ]
    
    value_range = patient_df["completion_pct"].max() #- patient_df["completion_pct"].min()
    top_limit = patient_df["completion_pct"].max() + 0.1*value_range
    plt.ylim(0, top_limit)
    plt.xlabel("Date")
    plt.ylabel("UF Completion (%)")
    plt.title(f"UF Completion % Trend - {patient_id}")
    plt.xticks(x, patient_df["date"])
    plt.legend(handles=legend_elements, loc="best")
    plt.tight_layout()

    # Save the graph
    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    plt.savefig(os.path.join(graphs_folder, f"{patient_id}_4_UF_Completion.png"))
    plt.show()

# NUMBER OF DWELL CYCLES SCATTER PLOT
def plot_dwell_cycles_scatter_plot(patient_id, patient_df):
    print("Dwell Cycles")
    actual_df = patient_df[patient_df.loc[:,"is_predicted"]==False]
    pred_df = patient_df[patient_df.loc[:,"is_predicted"]==True]

    # Create scatter plot
    # plt.figure(figsize=(8, 6))
    plt.scatter(actual_df['date'], actual_df['dwell_cycles'],
                        color="#800080", marker="D", edgecolors="black", s=200, label="Actual")
    plt.scatter(pred_df['date'], pred_df['dwell_cycles'],
                        color="#ffffff", marker="*", edgecolors="#800080", s=450, label="Predicted")

    for idx, row in patient_df.iterrows():
        plt.text(row['date'], row['dwell_cycles'] + 0.1, f"{row['dwell_cycles']}", 
                ha="center", va="bottom", fontsize=10, weight="roman")
    
    # Customize legend with smaller markers
    actual_legend = mlines.Line2D([], [], color="#800080", marker='D', linestyle='None',
                                markersize=8, markeredgecolor='black', label='Actual')
    pred_legend = mlines.Line2D([], [], color="#ffffff", marker='*', linestyle='None',
                                markersize=12, markeredgecolor="#800080", label='Predicted')
    plt.legend(handles=[actual_legend, pred_legend])

    # Add labels and title
    plt.ylim(bottom=0.5, top=max(patient_df['dwell_cycles'])*1.2)
    plt.xlabel('Date')
    plt.ylabel('Number of Dwell Cycles')
    plt.yticks(range(1,max(patient_df['dwell_cycles'])+1))
    plt.title(f'Number of Dwell Cycles - {patient_id}')
    # plt.legend()
    plt.tight_layout()
    
    # Save the plot
    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    plt.savefig(os.path.join(graphs_folder, f"{patient_id}_3_Dwell_Cycles.png"))
    plt.show()


if __name__ == "__main__":
    patient_ids = ["Patient A", "Patient B", "Patient C", "Patient D", "Patient E"]
    for patient_id in patient_ids:
        plot_patient_trends_with_predictions(patient_id)
        print(f"{patient_id} DONE!")
        print("*"*50)