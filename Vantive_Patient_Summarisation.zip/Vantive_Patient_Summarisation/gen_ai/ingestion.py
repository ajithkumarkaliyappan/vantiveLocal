import os
import re
import json

from utils import original_data_folder

def load_patient_data(patient_id, folder=original_data_folder):
    print(f"\nLoading patient {patient_id}'s data")

    # Regex pattern: only patient_id + Day is fixed, rest can vary
    pattern = re.compile(rf".*{re.escape(patient_id)}_Day \d+\.json")
    patient_sessions = []
    matching_files = [f for f in os.listdir(folder) if pattern.match(f)]

    # Sort by day number
    matching_files = sorted(
        matching_files,
        key=lambda x: int(re.search(r"Day (\d+)", x).group(1))
    )

    for fname in matching_files:
        with open(os.path.join(folder, fname), "r") as infile:
            patient_sessions.append(json.load(infile))

    print(f"Loaded {len(patient_sessions)} sessions for {patient_id}")
    return patient_sessions