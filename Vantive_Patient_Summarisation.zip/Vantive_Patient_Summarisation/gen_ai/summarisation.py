import sys
sys.path.append('.')
sys.path.append('..')

import os
import json
from gen_ai.llm_connector import LLMConnector
from utils import all_summaries_json_file

def get_summarisation_prompt(patient_id, extracted_data):
    summarisation_prompt = f"""
        You are a dialysis medical assistant. Summarise the patient's overall status
        using the extracted daily data below.

        Patient: {patient_id}
        Data: {extracted_data}

        Provide:
        - **Health trend (Stable, Declining, Critical)**
        - **Key findings** (weight, blood pressure, fill/drain balance, any anomalies, etc.). Do not mention about any missing data under this heading.
        - **Alerts**
        - **Short recommendation**
        Be concise with your insights.
        
        Provide your response in a JSON format with the following keys:
        - patient_id
            - Short_summary: One line sumamry of the patient's health
            - Colour_code (green, orange or red) - green if the health is good, Red if the patient needs immediate attention (critical)
                or orange if the patient's health is declining but not critical. Base it solely on the patient's health status.
            - Overall_summary: All the 4 points mentioned previously (Health_trend, Key_findings, Alerts, Short_recommendation)
            The value for each key under Overall_summary should be in string format with proper bullet points wherever required.\
            Use hyphens (-) for bullet points in all sections.
        """ 
    return summarisation_prompt

def summarise_patient_attributes(patient_id, extracted_data):
    # Load existing data if file exists
    if os.path.exists(all_summaries_json_file):
        with open(all_summaries_json_file, "r", encoding="utf-8") as f:
            try:
                all_summaries = json.load(f)
            except json.JSONDecodeError:
                all_summaries = {}
    else:
        all_summaries = {}

    if patient_id in all_summaries:
        patient_summary = all_summaries[patient_id]
        print(f"Summary file exists for {patient_id}")
        return patient_summary
    
    # Summarise using LLM
    llm = LLMConnector()
    print(f"Creating summary for {patient_id}")
    summarisation_prompt = get_summarisation_prompt(patient_id, extracted_data)
    summary = llm.get_response(
        summarisation_prompt,
        system_prompt="You are a medical assistant specialised in dialysis patient summaries."
    )
    # Parse the LLM's output into a JSON object
    try:
        summary_json = json.loads(summary)
    except json.JSONDecodeError:
        print(f"Could not parse summary for patient {patient_id} as JSON. Saving as text.")
        summary_json = {"raw_response": summary}

    # Add or update the current patient's summary
    all_summaries[patient_id] = summary_json

    # Write the updated data back to the file
    with open(all_summaries_json_file, "w", encoding="utf-8") as f:
        json.dump(all_summaries, f, indent=4, ensure_ascii=False)
    return summary_json