import sys
sys.path.append('.')
sys.path.append('..')

import streamlit as st
import json
import os
import requests
import pandas as pd
from pathlib import Path
from utils import vantive_logo, all_summaries_json_file, graph_folder

# Initialize page state
if "page" not in st.session_state:
    st.session_state.page = "home"

# initialize the scroll flag
if "scroll_to_top_flag" not in st.session_state:
    st.session_state.scroll_to_top_flag = False

def navigate_to(page_name):
    st.session_state.page = page_name
    st.session_state.scroll_to_top_flag = True
    st.rerun()

# Display 'back' button in patient page
if st.session_state.page == "patient":
    if st.button("Back to Homepage"):
        navigate_to("home")

st.logo(vantive_logo, size="large")
st.markdown("""<h1 style='text-align:center;
                    color: #800080;'> VANTIVE HEALTHCARE </h1>""",
                    unsafe_allow_html=True)
st.write(" ")

# Load data
if not os.path.exists(all_summaries_json_file):
    st.error("No patient summaries found.")
    st.stop()

with open(all_summaries_json_file, "r", encoding="utf-8") as f:
    all_summaries = json.load(f)
 
# Define custom priority order for sorting
priority = {"red": 1, "orange": 2, "green": 3}

# Sort all_summaries based on the Colour_code
sorted_summaries = dict(
    sorted(
        all_summaries.items(),
        key=lambda item: priority.get(item[1].get("Colour_code", "").lower(), 4)
    )
)

# --- 🎨 Define color mapping function ---
def color_index(row):
    colour_code = str(row["Colour_code"]).lower()
    if colour_code == "red":
        return "background-color: #ff6347;"   # red
    elif colour_code == "orange":
        return "background-color: #ffe135;"   # yellowish orange
    elif colour_code == "green":
        return "background-color: #adff2f;"   # green
    else:
        return "background-color: #f0f0f0;" 

# --- 🪄 Apply color only to index ---
def highlight_index(df):
    styles = pd.DataFrame("", index=df.index, columns=df.columns)
    # Apply color to each row’s index cell
    for idx in df.index:
        colour_code = str(df.loc[idx, "Colour_code"]).lower()
        if colour_code == "red":
            styles.loc[idx, :] = "background-color: #ff6347;"
        elif colour_code == "orange":
            styles.loc[idx, :] = "background-color: #ffe135;"
        elif colour_code == "green":
            styles.loc[idx, :] = "background-color: #adff2f;"
        else:
            styles.loc[idx, :] = "background-color: #f0f0f0;"
    return styles

# Navigation logic
if st.session_state.page == "home":
    st.set_page_config(page_title="Home", layout="wide", page_icon=vantive_logo)

    df = pd.DataFrame(sorted_summaries)
    df_transpose = df.T

    table_df = df_transpose[['Short_summary', 'Overall_summary']].copy() #, 'Colour_code'
    table_df["Health Trend"] = table_df["Overall_summary"].apply(lambda x: x.get("Health_trend") if isinstance(x, dict) else None)
    table_df.drop(columns=['Overall_summary'], inplace=True)
    table_df.rename(columns={'Short_summary':'Details'}, inplace=True)
    table_df = table_df[['Health Trend', 'Details']]

    # --- ✨ Style the DataFrame ---       
    hex_map = {
        "red": "#ff6347",
        "orange": "#ffff66", # "#ffe135",
        "green": "#b2ec5d" # "#d0ff14" 
    }
    
    def style_index(index):
        return [f"background-color: {hex_map.get(df_transpose.loc[i, 'Colour_code'], '#ffffff')}" for i in index]

    # Apply styling
    styled_df = table_df.style.apply_index(style_index, axis=0)
    
    st.markdown(styled_df.to_html(), unsafe_allow_html=True)
    st.write(" ")
    st.header("Dialysis Patient Summary Dashboard", divider="violet")
    col1, col2 = st.columns([0.6, 0.4], gap="large")
    
    # Iterate over patients
    for patient_id, patient_summary in sorted_summaries.items():
        short_summary = patient_summary.get("Short_summary", "No short summary available.")
        colour_code = patient_summary.get("Colour_code", "#f0f0f0").lower()
        if colour_code == "red":
            box_colour = "#ff6347"  
        elif colour_code == "green":
            box_colour = "#adff2f"
        elif colour_code == "orange":
            box_colour = "#ffe135"

        # Display as full-width colored buttons (stacked)
        with col1:
            st.markdown(
                f"""
                <div style="
                    background-color:{box_colour};
                    border-radius:8px;
                    padding:10px;
                    margin-bottom:8px;">
                    <form action="/Patient_Summary" method="get">
                        <input type="hidden" name="patient_id" value="{patient_id}">
                        <button style="
                            background:none;
                            border:none;
                            color:black;
                            font-size:18px;
                            font-weight:600;
                            cursor:pointer;
                            text-align:left;
                            width:100%;">
                            {patient_id}
                        </button>
                        <p style="margin-top:5px;"> {short_summary}</p>
                    </form>
                </div>
                """,
                unsafe_allow_html=True
            )
            # Button to navigate to detailed page
            if st.button(f"View {patient_id}'s Summary", key=patient_id):
                st.session_state["selected_patient"] = patient_id
                navigate_to("patient")
                
    graphs_folder = Path(graph_folder)
    # Iterate only over .png files, excluding subfolders
    png_files = [file for file in graphs_folder.iterdir() if file.is_file() and file.suffix == '.png']
    with col2:
        for graph in png_files:
            st.image(graph)

elif st.session_state.page == "patient":
    from streamlit_scroll_to_top import scroll_to_here
    st.set_page_config(page_title="Patient Summary", layout="wide", page_icon=vantive_logo)
    # st.logo("ui_streamlit/Vantive_logo.jpg", size="large")
    # st.markdown("""<h1 style='text-align:center;
    #                 color: #800080;'> VANTIVE HEALTHCARE </h1>""",
    #                 unsafe_allow_html=True)

    # If flag is set, call scroll_to_here once
    if st.session_state.scroll_to_top_flag:
        scroll_to_here(0, key="top")  # scroll to top
        st.session_state.scroll_to_top_flag = False
    
    patient_id = st.session_state.selected_patient
    
    if patient_id not in all_summaries:
        with st.spinner(f"Generating summary for {patient_id}..."):
            url = "http://127.0.0.1:8000/patient_data_summarisation/"
            payload = {"patient_id": str(patient_id)}
            response = requests.post(url=url, json=payload).json()
            patient_summary = response.get('summary')
    else:        
        patient_summary = all_summaries[patient_id]

    st.subheader(f"Detailed Summary for {patient_id}", divider="violet")
    
    col1, col2 = st.columns([0.6, 0.4], gap="medium")
    
    # Display data neatly
    with col1:
        if "Overall_summary" in patient_summary:
            overall = patient_summary.get("Overall_summary", {})
            # Health Trend
            st.markdown(f"<h5>Health Trend</h5>", unsafe_allow_html=True)
            st.write(overall.get('Health_trend', 'N/A'))
            # Key Findings
            key_findings = overall.get('Key_findings', 'N/A')
            st.markdown(f"<h5>Key Findings</h5>", unsafe_allow_html=True)
            if isinstance(key_findings, list):
                for finding in key_findings:
                    st.write(f"- {finding}")
            else:
                st.write(key_findings)
            # Alerts
            alerts = overall.get('Alerts', 'N/A')
            st.markdown(f"<h5>Alerts Needing Doctor's Attention</h5>", unsafe_allow_html=True)
            if isinstance(alerts, list):
                for alert in alerts:
                    st.write(f"- {alert}")
            else:
                st.write(alerts)
            # Recommendations
            recommendations = overall.get('Short_recommendation', 'N/A')
            st.markdown(f"<h5>Recommendations</h5>", unsafe_allow_html=True)
            if isinstance(recommendations, list):
                for recommendation in recommendations:
                    st.write(f"- {recommendation}")
            else:
                st.write(recommendations)
            
        # st.markdown("<h5>Short Summary:</h5>", unsafe_allow_html=True)
        # st.info(patient_summary.get("Short_summary", "N/A"))
    
    with col2:
        graphs_folder = Path(os.path.join(graph_folder, f"{patient_id}"))      
        # graphs_folder = Path("graphs/gpt5_graphs")
        # all_graphs = Path(graphs_folder)
        for graph in graphs_folder.iterdir():
            st.image(graph)