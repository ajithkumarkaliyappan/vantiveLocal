import streamlit as st
import requests
from pathlib import Path

st.set_page_config(page_title="Vantive Summarisation", layout="wide")
st.header("VANTIVE HEALTHCARE", divider="violet")

patient_id = st.selectbox("Please select patient ID", 
                          ("Patient A", "Patient B", "Patient C", "Patient D", "Patient E"),
                          index= None, placeholder="Patient ID", 
                          width=300)

if patient_id:
    with st.spinner(f"Generating summary for {patient_id}..."):
        url = "http://127.0.0.1:8000/patient_data_summarisation/"
        payload = {"patient_id": str(patient_id)}
        response = requests.post(url=url, json=payload).json()
        # print(f"RESPONSE: {response}")
        patient_summary = response.get('summary')
        col1, col2, col3 = st.columns([0.4, 0.3, 0.3])
        with col1:
            st.write(patient_summary)
        patient_id = patient_id.replace(" ", "_")
        graph_folder = Path(f"graphs/{patient_id}")
        with col2:
            for graph in graph_folder.iterdir():
                st.image(graph)
        
        graph_folder = Path('graphs')
        # Iterate only over .png files, excluding subfolders
        png_files = [file for file in graph_folder.iterdir() if file.is_file() and file.suffix == '.png']
        with col3:
            for graph in png_files:
                st.image(graph)
                # st.pyplot(graph)