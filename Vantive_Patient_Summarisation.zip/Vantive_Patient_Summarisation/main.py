import sys
sys.path.append('.')
sys.path.append('..')

import os
import json
from gen_ai.ingestion import load_patient_data
from gen_ai.extraction import extract_attributes
from gen_ai.prediction import predict_next_uf_and_dwell
from gen_ai.summarisation import summarise_patient_attributes
# from gen_ai.graph_generation import plot_patient_trends
from gen_ai.new_graph_generation import plot_patient_trends_with_predictions
from utils import gpt5_processed_patient_data_folder, original_data_folder, graph_folder

def process_patient(patient_id, data_folder=original_data_folder):
    # Load patient data
    sessions = load_patient_data(patient_id, data_folder)
    patient_id = patient_id.replace(" ", "_")

    # First LLM call: Extract important attributes
    processed_patient_json = os.path.join(gpt5_processed_patient_data_folder, f"Processed_{patient_id}.json")
    if os.path.exists(processed_patient_json):
        print(f"Processed data available for {patient_id}. Loading JSON file...")
        with open(processed_patient_json, "r", encoding="utf-8") as f:
            extracted_data = json.load(f)
    else:
        extracted_data = extract_attributes(patient_id, sessions)
    # print("\n--- Extracted Data ---")
    # print(json.dumps(extracted_data, indent=2))

    # Prediction using LLM
    prediction = predict_next_uf_and_dwell(patient_id, extracted_data)
    print(prediction)

    # Second LLM call: Summarise
    patient_summary = summarise_patient_attributes(patient_id, extracted_data)

    # Plot graphs
    graphs_folder = os.path.join(graph_folder, f"{patient_id}")
    files = [f"{patient_id}_2_BP.png", f"{patient_id}_1_Weight.png", f"{patient_id}_3_Dwell_cycles.png", f"{patient_id}_4_UF_Completion.png"]
    if not all(os.path.exists(os.path.join(graphs_folder, f)) for f in files):
        print("Some graphs are missing")
        # plot_patient_trends_with(extracted_data, patient_id)
        plot_patient_trends_with_predictions(patient_id)
    else:
        print("All graphs readily available")
    return extracted_data, patient_summary

if __name__ == "__main__":
    # patient_ids = ["Patient A", "Patient B", "Patient C", "Patient D", "Patient E"]
    patient_ids = ["Patient E"]
    for patient_id in patient_ids:
        extracted, summary = process_patient(patient_id, data_folder="data/Claria Json_Updated Treatment Files")
        # print(summary.get('Colour_code'))
        print("DONE!")
        print("*"*50)