import sys
sys.path.append('.')
sys.path.append('..')

import os
vantive_logo = os.path.join('ui_streamlit', 'Vantive_logo.jpg')
original_data_folder = os.path.join("data", "Claria Json_Updated Treatment Files")
gpt4_processed_patient_data_folder = os.path.join("data", "gpt4_processed_data", "Processed_Patient_Data")
gpt5_processed_patient_data_folder = os.path.join("data", "gpt5_processed_data", "Processed_Patient_Data")
prediction_csv_file = os.path.join("data", "gpt5_processed_data", "predictions.csv")
all_summaries_json_file = os.path.join("data", "gpt5_processed_data", "All_patient_summaries.json")
graph_folder = os.path.join("graphs", "gpt5_graphs")

import streamlit.components.v1 as components

# Streamlit scroll to top using JS
def scroll_to_top():
    components.html(
        """
        <script>
        (function() {
            // Scroll immediately
            window.scrollTo(0, 0);

            // Then observe DOM changes until Streamlit finishes rendering
            const observer = new MutationObserver((mutations, obs) => {
                // Wait until Streamlit's main content is visible
                const main = document.querySelector('section.main');
                if (main) {
                    window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
                    obs.disconnect();  // stop observing once done
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        })();
        </script>
        """,
        height=0,
    )
