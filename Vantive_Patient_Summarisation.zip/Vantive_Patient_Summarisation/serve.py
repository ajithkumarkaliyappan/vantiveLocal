import sys
sys.path.append('.')
sys.path.append('..')

from fastapi import FastAPI
from main import process_patient
from pydantic import BaseModel

app = FastAPI()

class PatientRequest(BaseModel):
    patient_id: str

@app.post("/patient_data_summarisation/")
async def display_patient_summary(request: PatientRequest):
    extract, summary = process_patient(patient_id=request.patient_id)
    return {"summary": summary}