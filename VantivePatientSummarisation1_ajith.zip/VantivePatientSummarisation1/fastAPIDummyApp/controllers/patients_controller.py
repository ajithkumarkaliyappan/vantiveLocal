
from fastapi import APIRouter, Depends, HTTPException, status

from ..schemas import Patient, PaginatedPatientsResponse, PatientSummary, ForecastResponse
from ..auth import get_current_doctor
from ..data import PATIENTS, SUMMARIES
from ..utils.pagination import PaginationParams, paginate_items

router = APIRouter(prefix='/api/patients', tags=['Patients'])

@router.get('', response_model=PaginatedPatientsResponse)
def list_patients(params: PaginationParams = Depends(), current=Depends(get_current_doctor)):
    result = paginate_items(PATIENTS, params)
    items = [Patient(**p) for p in result['items']]
    result['items'] = items
    return result

@router.get('/{patient_id}/summary', response_model=PatientSummary)
def get_summary(patient_id: str, current=Depends(get_current_doctor)):
    summary = SUMMARIES.get(patient_id)
    if not summary:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Patient summary not found')
    return summary

@router.get('/{patient_id}/forecast', response_model=ForecastResponse)
def get_forecast(patient_id: str, current=Depends(get_current_doctor)):
    summary = SUMMARIES.get(patient_id)
    if not summary:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Patient summary not found')
    diagnosis = summary.get('diagnosis','')
    base = 0.5
    if 'Hypertension' in diagnosis:
        base = 0.78
    elif 'Diabetes' in diagnosis:
        base = 0.72
    elif 'Hyperlipidemia' in diagnosis:
        base = 0.65
    risk_level = 'High' if base >= 0.75 else ('Moderate' if base >= 0.6 else 'Low')
    recommendations = [
        'Increase physical activity',
        'Reduce sodium intake' if 'Hyper' in diagnosis or 'Hypertension' in diagnosis else 'Balanced diet',
        'Regular follow-up'
    ]
    return ForecastResponse(patient_id=patient_id, risk_score=base, risk_level=risk_level, recommendations=recommendations)
