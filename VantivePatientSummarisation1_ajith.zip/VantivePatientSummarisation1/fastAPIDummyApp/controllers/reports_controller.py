
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse

from ..auth import get_current_doctor
from ..data import PATIENTS, SUMMARIES
from ..pdf import generate_patient_pdf, OUTPUT_DIR

router = APIRouter(prefix='/api', tags=['Reports'])

@router.post('/patients/{patient_id}/export/pdf')
def export_pdf(patient_id: str, current=Depends(get_current_doctor)):
    patient = next((p for p in PATIENTS if p['patient_id'] == patient_id), None)
    if not patient:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Patient not found')
    summary = SUMMARIES.get(patient_id) or {}
    diagnosis = summary.get('diagnosis','')
    base = 0.5
    if 'Hypertension' in diagnosis:
        base = 0.78
    elif 'Diabetes' in diagnosis:
        base = 0.72
    elif 'Hyperlipidemia' in diagnosis:
        base = 0.65
    risk_level = 'High' if base >= 0.75 else ('Moderate' if base >= 0.6 else 'Low')
    recommendations = [
        'Increase physical activity',
        'Reduce sodium intake' if 'Hyper' in diagnosis or 'Hypertension' in diagnosis else 'Balanced diet',
        'Regular follow-up'
    ]
    forecast = { 'patient_id': patient_id, 'risk_score': base, 'risk_level': risk_level, 'recommendations': recommendations }

    filename = generate_patient_pdf(patient, summary, forecast)
    return { 'status': 'success', 'download_url': f"/api/reports/{filename}" }

@router.get('/reports/{filename}')
def download_report(filename: str, current=Depends(get_current_doctor)):
    path = OUTPUT_DIR + '/' + filename
    try:
        return FileResponse(path, media_type='application/pdf', filename=filename)
    except Exception:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Report not found')
