
from fastapi import APIRouter, HTTPException, status

from ..schemas import DoctorLoginRequest, TokenResponse
from ..auth import authenticate_doctor, create_access_token
from ..config import ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter(prefix='/api/auth', tags=['Auth'])

@router.post('/login', response_model=TokenResponse)
def login(payload: DoctorLoginRequest):
    doctor = authenticate_doctor(payload.username, payload.password)
    print("DOCTOR: ", doctor)
    if not doctor:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid username or password')
    token = create_access_token({
        'doctor_id': doctor['doctor_id'],
        'username': doctor['username'],
    })
    return TokenResponse(token=token, expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60, doctor_id=doctor['doctor_id'])
