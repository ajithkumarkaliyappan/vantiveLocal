
import uuid
from typing import Any, Dict
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError

from .schemas import ErrorResponse

class AppException(Exception):
    def __init__(self, code: str, message: str, details: Dict[str, Any] | None = None):
        self.code = code
        self.message = message
        self.details = details or {}


def get_request_id(request: Request) -> str:
    rid = getattr(request.state, 'request_id', None)
    return rid or str(uuid.uuid4())


def app_exception_handler(request: Request, exc: AppException):
    return JSONResponse(status_code=400, content=ErrorResponse(
        code=exc.code, message=exc.message, details=exc.details, request_id=get_request_id(request)
    ).model_dump())


def http_exception_handler(request: Request, exc: HTTPException):
    code_map = {404: 'NOT_FOUND', 401: 'UNAUTHORIZED', 403: 'FORBIDDEN'}
    code = code_map.get(exc.status_code, 'HTTP_ERROR')
    return JSONResponse(status_code=exc.status_code, content=ErrorResponse(
        code=code, message=str(exc.detail), details={}, request_id=get_request_id(request)
    ).model_dump())


from .utils.serializers import ensure_jsonable

def validation_exception_handler(request: Request, exc: RequestValidationError):
    details = {'errors': ensure_jsonable(exc.errors())}
    payload = ErrorResponse(
        code='VALIDATION_ERROR',
        message='Request validation failed',
        details=details,
        request_id=get_request_id(request)
    ).model_dump()
    return JSONResponse(status_code=422, content=ensure_jsonable(payload))
