
from typing import Any
from pydantic import BaseModel

def ensure_jsonable(obj: Any) -> Any:
    """Make any complex/bytes payload JSON-safe."""
    try:
        import datetime
    except Exception:
        datetime = None

    if isinstance(obj, bytes):
        try:
            return obj.decode('utf-8')
        except Exception:
            return obj.hex()                    # safe fallback
    if isinstance(obj, BaseModel):
        return obj.model_dump()
    if isinstance(obj, (list, tuple)):
        return [ensure_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: ensure_jsonable(v) for k, v in obj.items()}
    if datetime and isinstance(obj, datetime.datetime):
        return obj.isoformat()
    return obj
