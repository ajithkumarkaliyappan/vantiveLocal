
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from typing import Literal

class PaginationParams(BaseModel):
    page: int = Field(1, ge=1)
    page_size: int = Field(10, ge=1, le=100)
    sort_by: Literal['patient_id','name','age','gender'] = 'patient_id'
    sort_dir: Literal['asc','desc'] = 'asc'
    search: Optional[str] = None


def paginate_items(items: List[Dict[str, Any]], params: PaginationParams):
    filtered = items
    if params.search:
        q = params.search.lower()
        filtered = [i for i in items if q in i.get('name','').lower() or q in i.get('patient_id','').lower()]

    reverse = params.sort_dir == 'desc'
    filtered = sorted(filtered, key=lambda x: x.get(params.sort_by), reverse=reverse)

    total = len(filtered)
    start = (params.page - 1) * params.page_size
    end = start + params.page_size
    page_items = filtered[start:end]

    total_pages = max(1, (total + params.page_size - 1) // params.page_size)
    has_next = params.page < total_pages
    has_prev = params.page > 1

    return {
        'items': page_items,
        'page': params.page,
        'page_size': params.page_size,
        'total': total,
        'total_pages': total_pages,
        'has_next': has_next,
        'has_prev': has_prev,
    }
