
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
# import jwt

from .config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES
from .data import DOCTORS

security = HTTPBearer()



def create_access_token(subject: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = subject.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    if isinstance(token, bytes):  # ensure JSON-serializable
        token = token.decode('utf-8')
    return token



def authenticate_doctor(username: str, password: str) -> Optional[dict]:
    doctor = DOCTORS.get(username)
    if not doctor:
        return None
    if doctor.get("password_plain") and doctor["password_plain"] == password:
        return doctor
    return None


def get_current_doctor(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        doctor_id: str = payload.get("doctor_id")
        username: str = payload.get("username")
        if doctor_id is None or username is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload")
        doctor = DOCTORS.get(username)
        if not doctor or doctor.get("doctor_id") != doctor_id:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Doctor not found")
        return doctor
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")


