
from typing import List, Optional, Literal, Any, Dict
from pydantic import BaseModel, Field

class DoctorLoginRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=6, max_length=128)

class TokenResponse(BaseModel):
    token: str
    expires_in: int
    doctor_id: str

class Patient(BaseModel):
    patient_id: str
    name: str
    age: int = Field(..., ge=0, le=120)
    gender: Literal['Male','Female','Other']

class PatientSummary(BaseModel):
    patient_id: str
    diagnosis: str
    medications: List[str]
    last_visit: str

class ForecastResponse(BaseModel):
    patient_id: str
    risk_score: float = Field(..., ge=0.0, le=1.0)
    risk_level: Literal['Low', 'Moderate', 'High']
    recommendations: List[str]

class PaginatedPatientsResponse(BaseModel):
    items: List[Patient]
    page: int
    page_size: int
    total: int
    total_pages: int
    has_next: bool
    has_prev: bool

class ErrorResponse(BaseModel):
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None
    request_id: Optional[str] = None
