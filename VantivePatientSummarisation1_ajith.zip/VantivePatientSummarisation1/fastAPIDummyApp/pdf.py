
import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'generated_reports')


def generate_patient_pdf(patient: dict, summary: dict, forecast: dict) -> str:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    filename = f"{patient['patient_id']}-summary.pdf"
    path = os.path.join(OUTPUT_DIR, filename)

    c = canvas.Canvas(path, pagesize=A4)
    width, height = A4

    c.setFont("Helvetica-Bold", 16)
    c.drawString(2 * cm, height - 2 * cm, "Patient Medical Summary")

    c.setFont("Helvetica", 11)
    y = height - 3 * cm
    def line(text):
        nonlocal y
        c.drawString(2 * cm, y, text)
        y -= 0.8 * cm

    line(f"Patient ID: {patient['patient_id']}")
    line(f"Name: {patient['name']}")
    line(f"Age: {patient['age']}")
    line(f"Gender: {patient['gender']}")
    y -= 0.4 * cm

    c.setFont("Helvetica-Bold", 12)
    line("Medical Summary")
    c.setFont("Helvetica", 11)
    line(f"Diagnosis: {summary.get('diagnosis', 'N/A')}")
    meds = ', '.join(summary.get('medications', [])) if summary.get('medications') else 'N/A'
    line(f"Medications: {meds}")
    line(f"Last Visit: {summary.get('last_visit', 'N/A')}")
    y -= 0.4 * cm

    c.setFont("Helvetica-Bold", 12)
    line("Forecast")
    c.setFont("Helvetica", 11)
    line(f"Risk Score: {forecast.get('risk_score', 0):.2f}")
    line(f"Risk Level: {forecast.get('risk_level', 'N/A')}")
    recs = forecast.get('recommendations', [])
    if recs:
        line("Recommendations:")
        for r in recs:
            line(f" - {r}")

    c.showPage()
    c.save()
    return filename
