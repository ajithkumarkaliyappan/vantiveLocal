
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi import HTTPException

from .config import APP_NAME
from .middleware import RequestIDMiddleware
from .errors import app_exception_handler, http_exception_handler, validation_exception_handler, AppException
from .controllers.auth_controller import router as auth_router
from .controllers.patients_controller import router as patients_router
from .controllers.reports_controller import router as reports_router

app = FastAPI(title=APP_NAME, version="1.1.1")

app.add_middleware(RequestIDMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(AppException, app_exception_handler)
app.add_exception_handler(HTTPException, http_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)

app.include_router(auth_router)
app.include_router(patients_router)
app.include_router(reports_router)

@app.get('/')
def root():
    return { 'service': APP_NAME, 'status': 'ok' }



# to run >> uvicorn fastAPIDummyApp.main:app --reload           