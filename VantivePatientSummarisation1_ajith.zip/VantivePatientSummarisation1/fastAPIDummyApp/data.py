
from typing import Dict, List

DOCTORS: Dict[str, dict] = {
    "doctor1": {
        "doctor_id": "D12345",
        "username": "doctor1",
        "password_plain": "Passw0rd!",
        "full_name": "Dr. Alice Johnson"
    }
}

PATIENTS: List[dict] = [
    {"patient_id": "P001", "name": "John Doe", "age": 45, "gender": "Male"},
    {"patient_id": "P002", "name": "Jane Smith", "age": 38, "gender": "Female"},
    {"patient_id": "P003", "name": "Arun Kumar", "age": 52, "gender": "Male"},
    {"patient_id": "P004", "name": "Aisha Begum", "age": 29, "gender": "Female"},
]

SUMMARIES: Dict[str, dict] = {
    "P001": {
        "patient_id": "P001",
        "diagnosis": "Hypertension",
        "medications": ["Amlodipine", "Lisinopril"],
        "last_visit": "2026-01-05"
    },
    "P002": {
        "patient_id": "P002",
        "diagnosis": "Type 2 Diabetes",
        "medications": ["Metformin"],
        "last_visit": "2025-12-20"
    },
    "P003": {
        "patient_id": "P003",
        "diagnosis": "Hyperlipidemia",
        "medications": ["Atorvastatin"],
        "last_visit": "2025-11-01"
    }
}
