
# Doctor-Patient Dummy REST API (FastAPI)

Features:
- Doctor authentication (JWT)
- Patients list with **pagination, sorting, search**
- Patient medical summaries
- Dummy forecasts
- PDF export & download
- Global error handling (standardized JSON)
- Request ID middleware

## Run

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

If running from a parent folder, use:
```bash
python -m uvicorn doctor_patient_api.app.main:app --reload
```

## Pagination example
`GET /api/patients?page=1&page_size=10&sort_by=name&sort_dir=asc&search=john`
